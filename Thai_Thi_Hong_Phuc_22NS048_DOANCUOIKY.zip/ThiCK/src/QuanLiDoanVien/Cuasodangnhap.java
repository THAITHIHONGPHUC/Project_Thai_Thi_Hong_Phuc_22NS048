package QuanLiDoanVien;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Cuasodangnhap implements ActionListener{
JFrame cua_so_dang_nhap;
ImageIcon icon = new ImageIcon("icondoan.png");
JButton dangnhap ;
JTextField yeucauchidoan;
JPasswordField nhapmatkhau;
JTextArea email, matkhau, dnhap;
JLabel anhdoan;
ImageIcon Anhdoan = new ImageIcon("anhdoan.jpg");
Image Anh_doan, Anh;
JCheckBox xem_mk;
String chi_doan, Matkhau;

public static String DB_URL = "jdbc:mysql://localhost:3306/QLDV";
public static String USER_NAME = "root";
public static String PASSWORD = "16032004";
	Cuasodangnhap(){
		this.dangnhap = new JButton("Đăng nhập");
		this.dangnhap.setBounds(100, 270, 123, 30);
		this.dangnhap.setVisible(true);
		this.dangnhap.setFocusable(false);
		this.dangnhap.setFont(new Font("Cambria", Font.BOLD , 16));
		this.dangnhap.setBackground(new Color(255,255,225));
		this.dangnhap.addActionListener(this);
		
		this.anhdoan = new JLabel();
		this.anhdoan.setBounds(325,0,420,470);
		this.anhdoan.setBackground(Color.BLACK);
		this.anhdoan.setVisible(true);
		this.anhdoan.setOpaque(true);
		this.Anh = Anhdoan.getImage();
		this.Anh_doan = Anh.getScaledInstance(this.anhdoan.getWidth(),this.anhdoan.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon AnhDoan = new ImageIcon(Anh_doan);
		this.anhdoan.setIcon(AnhDoan);
		
		this.dnhap = new JTextArea("ĐĂNG NHẬP");
		this.dnhap.setBounds(73, 103, 200, 55);
		this.dnhap.setVisible(true);
		this.dnhap.setBackground(new Color(153, 180, 209));
		this.dnhap.setFont(new Font("Cambria", Font.BOLD, 35));
		this.dnhap.setEditable(false);
		this.dnhap.setFocusable(false);
		
		this.email = new JTextArea("Chi đoàn");
		this.email.setBounds(10, 168, 100, 22);
		this.email.setBackground(new Color(153, 180, 209));
		this.email.setVisible(true);
		this.email.setEditable(false);
		this.email.setFocusable(false);
		this.email.setFont(new Font("Cambria", Font.BOLD, 20));
		
		this.yeucauchidoan = new JTextField();
		this.yeucauchidoan.setBounds(105, 168, 215, 30);
		this.yeucauchidoan.setBackground(Color.white);
		this.yeucauchidoan.setEditable(true);
		this.yeucauchidoan.setVisible(true);
		this.yeucauchidoan.setFocusable(true);
		this.yeucauchidoan.setBorder(BorderFactory.createLineBorder(Color.black,2));
		this.yeucauchidoan.setFont(new Font("Cambria", Font.PLAIN, 17));
		this.yeucauchidoan.setForeground(Color.black);
		
		this.matkhau = new JTextArea("Mật khẩu");
		this.matkhau.setVisible(true);
		this.matkhau.setEditable(false);
		this.matkhau.setFocusable(false);
		this.matkhau.setBounds(10, 210, 90, 43);
		this.matkhau.setBackground(new Color(153, 180, 209));
		this.matkhau.setFont(new Font("Cambria", Font.BOLD, 20));
		
		this.nhapmatkhau = new JPasswordField();
		this.nhapmatkhau.setVisible(true);
		this.nhapmatkhau.setEditable(true);
		this.nhapmatkhau.setFocusable(true);
		this.nhapmatkhau.setBounds(105, 208, 215, 30);
		this.nhapmatkhau.setBorder(BorderFactory.createLineBorder(Color.black,2));
		this.nhapmatkhau.setBackground(Color.white);
		this.nhapmatkhau.setFont(new Font("Cambria", Font.PLAIN, 17));
		this.nhapmatkhau.setForeground(Color.black);
		
		this.xem_mk = new JCheckBox("Xem mật khẩu");
        this.xem_mk.setBounds(105, 240, 200, 25);
        this.xem_mk.setBackground(new Color(153, 180, 209));
        this.xem_mk.setForeground(Color.black);
        this.xem_mk.setFont(new Font("Cambria", Font.PLAIN, 14));
        this.xem_mk.addActionListener(this);
        this.xem_mk.setFocusable(false);
		
		this.cua_so_dang_nhap = new JFrame("QUẢN LÝ ĐOÀN VIÊN");
		this.cua_so_dang_nhap.setSize(760,500);
		this.cua_so_dang_nhap.setVisible(true);
		this.cua_so_dang_nhap.setLayout(null);
		this.cua_so_dang_nhap.setResizable(false);
		this.cua_so_dang_nhap.setIconImage(icon.getImage());
		this.cua_so_dang_nhap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.cua_so_dang_nhap.setLocationRelativeTo(null);
		this.cua_so_dang_nhap.getContentPane().setBackground(new Color(153, 180, 209));
		
		this.cua_so_dang_nhap.add(this.anhdoan);
		this.cua_so_dang_nhap.add(this.dangnhap);
		this.cua_so_dang_nhap.add(this.dnhap);
		this.cua_so_dang_nhap.add(this.email);
		this.cua_so_dang_nhap.add(this.yeucauchidoan);
		this.cua_so_dang_nhap.add(this.matkhau);
		this.cua_so_dang_nhap.add(this.nhapmatkhau);
		this.cua_so_dang_nhap.add(this.xem_mk);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(this.xem_mk.isSelected()) {
			this.nhapmatkhau.setEchoChar((char)0);
		}else {
			this.nhapmatkhau.setEchoChar('*');
		}
		if(e.getSource() == this.dangnhap) {
			if(this.yeucauchidoan.getText().length() != 0) {
				if(this.nhapmatkhau.getText().length() != 0) {
					try {
					Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
                    Statement stmt = connection.createStatement();
                    ResultSet rs1 = stmt.executeQuery(
                            "Select Ten_CD , cast(aes_decrypt(MK,'key123') as char) as xem_MK from qldv.chi_doan where Ten_CD = '"+this.yeucauchidoan.getText()+"'");
                    while(rs1.next()) {
                    	this.chi_doan = rs1.getString(1);
                    	this.Matkhau = rs1.getString(2);
                    }
                    if(this.chi_doan.equals(this.yeucauchidoan.getText()) == true) {
                    	if(this.Matkhau.equals(this.nhapmatkhau.getText()) == true) {
                    		this.cua_so_dang_nhap.dispose();
                    		new Giaodienchinh(this.chi_doan);
                    	}else {
                    		JOptionPane.showMessageDialog(null, "Sai mật khẩu!",
                                    "Lưu ý!!!", JOptionPane.WARNING_MESSAGE); 	
                    	}
                    }else {
                    	JOptionPane.showMessageDialog(null, "Chi đoàn không tồn tại  !",
                                "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
                    }
					}catch (Exception ex){
						JOptionPane.showMessageDialog(null, "Sai thông tin!",
		                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(null, "Hãy nhập mật khẩu!",
                            "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
				}
			}else{
				JOptionPane.showMessageDialog(null, "Hãy nhập chi đoàn!",
                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
			}
		}
		
	}
}
