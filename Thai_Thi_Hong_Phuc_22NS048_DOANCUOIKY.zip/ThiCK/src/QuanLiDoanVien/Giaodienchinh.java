package QuanLiDoanVien;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSetMetaData;

public class Giaodienchinh implements ActionListener {
	public static String DB_URL = "jdbc:mysql://localhost:3306/QLDV";
	public static String USER_NAME = "root";
	public static String PASSWORD = "16032004";
	
JFrame giao_dien_chinh;
JTextArea doanthanhnien, qldoanvien , ChiDoan,Ma_DV, Ten_DV, Ngay_KN, Thang_KN, Nam_KN, KETNAPDV, CHINHSUADV, MA_DV_CHINHSUA, Ten_DV_CHINHSUA,Ngay_CHINHSUA,Thang_CHINHSUA,Nam_CHINHSUA , HUONG_DAN, MADV_TD, TENDV_TD, NGAY_TD,THANG_TD,NAM_TD;
JTextField Ma_DV_TF , Ten_DV_TF, Ngay_KN_TF, Thang_KN_TF, Nam_KN_TF, MA_DV_CHINHSUA_TF, TEN_DV_CHINHSUA_TF,Ngay_CHINHSUA_TF,Thang_CHINHSUA_TF,Nam_CHINHSUA_TF , MADV_TD_TF, TENDV_TD_TF,NGAY_TF,THANG_TF,NAM_TF; 
JButton ketnapdv, chinhsua, dangxuat, NUT_THEM, NUT_CHINH_SUA, NUT_XOA;
JLabel anh1, anh2;
ImageIcon icon = new ImageIcon("icondoan.png");
ImageIcon anhd1 = new ImageIcon("anhdoan.jpg");
ImageIcon alert = new ImageIcon("alert.jpg");
JLabel menu_group , welcome_label, Ban_Them, Ban_Them_Table, Ban_chinhsua, Ban_chinhsua_Table;
JPanel phong_chinh ,phong_them, Phong_Chinhsua;
JTable Them, chinh_sua;
JScrollPane Them_Scr, chinh_sua_Scr;
DefaultTableModel Them_DFT,Chinhsua_DFT;
String chidoan, Ma_Chi_Doan;
String MADV, TENDV, NGAY , THANG, NAM;
LocalDateTime localDate;
String Madv , tendv , ngay , thang ,nam ;
int year, month, day;

	Giaodienchinh(String ten_cd){
		this.localDate = LocalDateTime.now();
         this.year = localDate.getYear();
         this.day = localDate.getDayOfMonth();
         this.month = localDate.getMonthValue();
        
		this.chidoan = ten_cd;
		this.doanthanhnien = new JTextArea("ĐOÀN THANH NIÊN CỘNG SẢN HỒ CHÍ MINH");
		this.doanthanhnien.setVisible(true);
		this.doanthanhnien.setEditable(false);
		this.doanthanhnien.setFocusable(false);
		this.doanthanhnien.setBackground(new Color(0,0,0,0));
		this.doanthanhnien.setBounds(441, 400, 695, 55);
		this.doanthanhnien.setFont(new Font("Cambria", Font.PLAIN, 35));
		this.doanthanhnien.setForeground(new Color(0, 0, 128));
		
		this.qldoanvien = new JTextArea("QUẢN LÍ ĐOÀN VIÊN");
		this.qldoanvien.setVisible(true);
		this.qldoanvien.setEditable(false);
		this.qldoanvien.setFocusable(false);
		this.qldoanvien.setBackground(new Color(0,0,0,0));
		this.qldoanvien.setBounds(320, 450, 946, 118);
		this.qldoanvien.setFont(new Font("Cambria", Font.BOLD, 99));
		this.qldoanvien.setForeground(new Color(0, 0, 128));
		
		this.ChiDoan = new JTextArea("Chi đoàn "+ this.chidoan);
		this.ChiDoan.setVisible(true);
		this.ChiDoan.setEditable(false);
		this.ChiDoan.setFocusable(false);
		this.ChiDoan.setBackground(new Color(0,0,0,0));
		this.ChiDoan.setBounds(585, 570, 946, 118);
		this.ChiDoan.setFont(new Font("Cambria", Font.BOLD, 50));
		this.ChiDoan.setForeground(new Color(0, 0, 128));
		
		this.ketnapdv = new JButton("THÊM ĐOÀN VIÊN");
		this.ketnapdv.setVisible(true);
		this.ketnapdv.setFocusable(false);
		this.ketnapdv.setBorder(BorderFactory.createLineBorder(Color.black,3));
		this.ketnapdv.setFont(new Font("Cambria", Font.BOLD, 40));
		this.ketnapdv.setBackground(new Color(100, 149, 237));
		this.ketnapdv.addActionListener(this);
		
		this.KETNAPDV = new JTextArea("KẾT NẠP ĐOÀN VIÊN");
		this.KETNAPDV.setBounds(135,70,485,60);
		this.KETNAPDV.setFont(new Font("Cambria", Font.BOLD, 50));
		this.KETNAPDV.setBackground(new Color(0,0,0,0));
		this.KETNAPDV.setFocusable(false);
		this.KETNAPDV.setEditable(false);
		
		this.Ma_DV = new JTextArea("Mã đoàn viên");
		this.Ma_DV.setBounds(30,140,185,40);
		this.Ma_DV.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ma_DV.setBackground(new Color(0,0,0,0));
		this.Ma_DV.setFocusable(false);
		this.Ma_DV.setEditable(false);
		
		this.Ma_DV_TF = new JTextField();
		this.Ma_DV_TF.setBounds(240,140,400,40);
		this.Ma_DV_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ma_DV_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.Ten_DV = new JTextArea("Tên đoàn viên");
		this.Ten_DV.setBounds(30,195,197,40);
		this.Ten_DV.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ten_DV.setBackground(new Color(0,0,0,0));
		this.Ten_DV.setFocusable(false);
		this.Ten_DV.setEditable(false);
		
		this.Ten_DV_TF = new JTextField();
		this.Ten_DV_TF.setBounds(240,195,400,40);
		this.Ten_DV_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ten_DV_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.Ngay_KN = new JTextArea("Ngày kết nạp");
		this.Ngay_KN.setBounds(30,250,195,40);
		this.Ngay_KN.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ngay_KN.setBackground(new Color(0,0,0,0));
		this.Ngay_KN.setFocusable(false);
		this.Ngay_KN.setEditable(false);
		
		this.Ngay_KN_TF = new JTextField();
		this.Ngay_KN_TF.setBounds(240,250,400,40);
		this.Ngay_KN_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ngay_KN_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.Thang_KN = new JTextArea("Tháng kết nạp");
		this.Thang_KN.setBounds(30,305,199,40);
		this.Thang_KN.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Thang_KN.setBackground(new Color(0,0,0,0));
		this.Thang_KN.setFocusable(false);
		this.Thang_KN.setEditable(false);
		
		this.Thang_KN_TF = new JTextField();
		this.Thang_KN_TF.setBounds(240,305,400,40);
		this.Thang_KN_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Thang_KN_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

		this.Nam_KN = new JTextArea("Năm kết nạp");
		this.Nam_KN.setBounds(30,360,197,40);
		this.Nam_KN.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Nam_KN.setBackground(new Color(0,0,0,0));
		this.Nam_KN.setFocusable(false);
		this.Nam_KN.setEditable(false);
		
		this.Nam_KN_TF = new JTextField();
		this.Nam_KN_TF.setBounds(240,360,400,40);
		this.Nam_KN_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Nam_KN_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.NUT_THEM = new JButton("Thêm");
		this.NUT_THEM.setBounds(300,420,150,40);
		this.NUT_THEM.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NUT_THEM.setFocusable(false);
		this.NUT_THEM.addActionListener(this);
		
		this.Ban_Them = new JLabel();
		this.Ban_Them.setBackground(new Color(100, 149, 237));
		this.Ban_Them.setOpaque(true);
		this.Ban_Them.setVisible(true);
		this.Ban_Them.add(this.KETNAPDV);
		this.Ban_Them.add(this.Ma_DV);
		this.Ban_Them.add(this.Ma_DV_TF);
		this.Ban_Them.add(this.Ten_DV_TF);
		this.Ban_Them.add(this.Ten_DV);
		this.Ban_Them.add(this.Ngay_KN);
		this.Ban_Them.add(this.Ngay_KN_TF);
		this.Ban_Them.add(this.Thang_KN);
		this.Ban_Them.add(this.Thang_KN_TF);
		this.Ban_Them.add(this.Nam_KN);
		this.Ban_Them.add(this.Nam_KN_TF);
		this.Ban_Them.add(this.NUT_THEM);
		
		this.Them = new JTable();
		this.Them_Scr = new JScrollPane(this.Them);
		this.Them_Scr.setBorder(BorderFactory.createLineBorder(new Color(100, 149, 237)));
		this.Them.getTableHeader().setBackground(new Color(100, 149, 237));
		this.Them.getTableHeader().setForeground(Color.WHITE);
		this.Them.setForeground(Color.BLACK);
		this.Them.setFont(new Font("Cambria", Font.BOLD, 16));
		this.Them.setShowHorizontalLines(true);
		this.Them.setGridColor(new Color(100, 149, 237));
		this.Them.setFocusable(false);
		this.Them.setDefaultEditor(Object.class, null);
		this.Them_DFT = (DefaultTableModel) this.Them.getModel();
		
		this.Ban_Them_Table = new JLabel();
		this.Ban_Them_Table.setLayout( new BorderLayout());
		this.Ban_Them_Table.setBackground(Color.WHITE);
		this.Ban_Them_Table.setOpaque(true);
		this.Ban_Them_Table.setVisible(true);
		this.Ban_Them_Table.add(this.Them_Scr, BorderLayout.CENTER);
		
		this.phong_them = new JPanel();
		this.phong_them.setLayout(new GridLayout());
		this.phong_them.setBackground(Color.WHITE);
		this.phong_them.add(this.Ban_Them);
		this.phong_them.add(this.Ban_Them_Table);
		this.phong_them.setVisible(false);
		
		this.chinhsua = new JButton ("CHỈNH SỬA");
		this.chinhsua.setVisible(true);
		this.chinhsua.setFocusable(false);
		this.chinhsua.setBorder(BorderFactory.createLineBorder(Color.black,3));
		this.chinhsua.setFont(new Font("Cambria", Font.BOLD, 40));
		this.chinhsua.setBackground(new Color(100, 149, 237));
		this.chinhsua.addActionListener(this);
		
		this.CHINHSUADV = new JTextArea("CHỈNH SỬA THÔNG TIN");
		this.CHINHSUADV.setBounds(110,20,550,60);
		this.CHINHSUADV.setFont(new Font("Cambria", Font.BOLD, 50));
		this.CHINHSUADV.setBackground(new Color(0,0,0,0));
		this.CHINHSUADV.setFocusable(false);
		this.CHINHSUADV.setEditable(false);
		
		this.MA_DV_CHINHSUA = new JTextArea("Mã đoàn viên");
		this.MA_DV_CHINHSUA.setBounds(30,90,185,40);
		this.MA_DV_CHINHSUA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.MA_DV_CHINHSUA.setBackground(new Color(0,0,0,0));
		this.MA_DV_CHINHSUA.setFocusable(false);
		this.MA_DV_CHINHSUA.setEditable(false);
		
		this.MA_DV_CHINHSUA_TF = new JTextField();
		this.MA_DV_CHINHSUA_TF.setBounds(240,90,400,40);
		this.MA_DV_CHINHSUA_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.MA_DV_CHINHSUA_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.MADV_TD = new JTextArea("Đổi mã");
		this.MADV_TD.setBounds(30,145,185,40);
		this.MADV_TD.setFont(new Font("Cambria", Font.BOLD, 30));
		this.MADV_TD.setBackground(new Color(0,0,0,0));
		this.MADV_TD.setFocusable(false);
		this.MADV_TD.setEditable(false);
		
		this.MADV_TD_TF = new JTextField();
		this.MADV_TD_TF.setBounds(240,145,400,40);
		this.MADV_TD_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.MADV_TD_TF.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
		
		this.Ten_DV_CHINHSUA = new JTextArea("Tên đoàn viên");
		this.Ten_DV_CHINHSUA.setBounds(30,200,197,40);
		this.Ten_DV_CHINHSUA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ten_DV_CHINHSUA.setBackground(new Color(0,0,0,0));
		this.Ten_DV_CHINHSUA.setFocusable(false);
		this.Ten_DV_CHINHSUA.setEditable(false);
		
		this.TEN_DV_CHINHSUA_TF = new JTextField();
		this.TEN_DV_CHINHSUA_TF.setBounds(240,200,400,40);
		this.TEN_DV_CHINHSUA_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.TEN_DV_CHINHSUA_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.TENDV_TD = new JTextArea("Đổi tên");
		this.TENDV_TD.setBounds(30,255,197,40);
		this.TENDV_TD.setFont(new Font("Cambria", Font.BOLD, 30));
		this.TENDV_TD.setBackground(new Color(0,0,0,0));
		this.TENDV_TD.setFocusable(false);
		this.TENDV_TD.setEditable(false);
		
		this.TENDV_TD_TF = new JTextField();
		this.TENDV_TD_TF.setBounds(240,255,400,40);
		this.TENDV_TD_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.TENDV_TD_TF.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
		
		this.Ngay_CHINHSUA = new JTextArea("Ngày");
		this.Ngay_CHINHSUA.setBounds(30,310,180,40);
		this.Ngay_CHINHSUA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ngay_CHINHSUA.setBackground(new Color(0,0,0,0));
		this.Ngay_CHINHSUA.setFocusable(false);
		this.Ngay_CHINHSUA.setEditable(false);
		
		this.Ngay_CHINHSUA_TF = new JTextField();
		this.Ngay_CHINHSUA_TF.setBounds(240,310,400,40);
		this.Ngay_CHINHSUA_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Ngay_CHINHSUA_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.NGAY_TD = new JTextArea("Đổi ngày");
		this.NGAY_TD.setBounds(30,365,180,40);
		this.NGAY_TD.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NGAY_TD.setBackground(new Color(0,0,0,0));
		this.NGAY_TD.setFocusable(false);
		this.NGAY_TD.setEditable(false);
		
		this.NGAY_TF = new JTextField();
		this.NGAY_TF.setBounds(240,365,400,40);
		this.NGAY_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NGAY_TF.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
		
		this.Thang_CHINHSUA = new JTextArea("Tháng");
		this.Thang_CHINHSUA.setBounds(30,420,199,40);
		this.Thang_CHINHSUA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Thang_CHINHSUA.setBackground(new Color(0,0,0,0));
		this.Thang_CHINHSUA.setFocusable(false);
		this.Thang_CHINHSUA.setEditable(false);
		
		this.Thang_CHINHSUA_TF = new JTextField();
		this.Thang_CHINHSUA_TF.setBounds(240,420,400,40);
		this.Thang_CHINHSUA_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Thang_CHINHSUA_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.THANG_TD = new JTextArea("Đổi tháng");
		this.THANG_TD.setBounds(30,475,199,40);
		this.THANG_TD.setFont(new Font("Cambria", Font.BOLD, 30));
		this.THANG_TD.setBackground(new Color(0,0,0,0));
		this.THANG_TD.setFocusable(false);
		this.THANG_TD.setEditable(false);

		this.THANG_TF = new JTextField();
		this.THANG_TF.setBounds(240,475,400,40);
		this.THANG_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.THANG_TF.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
		
		this.Nam_CHINHSUA = new JTextArea("Năm");
		this.Nam_CHINHSUA.setBounds(30,530,197,40);
		this.Nam_CHINHSUA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Nam_CHINHSUA.setBackground(new Color(0,0,0,0));
		this.Nam_CHINHSUA.setFocusable(false);
		this.Nam_CHINHSUA.setEditable(false);
		
		this.Nam_CHINHSUA_TF = new JTextField();
		this.Nam_CHINHSUA_TF.setBounds(240,530,400,40);
		this.Nam_CHINHSUA_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.Nam_CHINHSUA_TF.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		
		this.NAM_TD = new JTextArea("Đổi năm");
		this.NAM_TD.setBounds(30,585,197,40);
		this.NAM_TD.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NAM_TD.setBackground(new Color(0,0,0,0));
		this.NAM_TD.setFocusable(false);
		this.NAM_TD.setEditable(false);
		
		this.NAM_TF = new JTextField();
		this.NAM_TF.setBounds(240,585,400,40);
		this.NAM_TF.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NAM_TF.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
		
		this.HUONG_DAN = new JTextArea("*Chọn trên bảng HOẶC điền từng thông tin");
		this.HUONG_DAN.setBounds(80,640,645,40);
		this.HUONG_DAN.setFont(new Font("Cambria", Font.BOLD, 30));
		this.HUONG_DAN.setBackground(new Color(0,0,0,0));
		this.HUONG_DAN.setFocusable(false);
		this.HUONG_DAN.setEditable(false);
		
		this.NUT_XOA = new JButton("XÓA");
		this.NUT_XOA.setBounds(195,695,130,40);
		this.NUT_XOA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NUT_XOA.setFocusable(false);
		this.NUT_XOA.addActionListener(this);
		
		this.NUT_CHINH_SUA = new JButton("CHỈNH SỬA");
		this.NUT_CHINH_SUA.setBounds(350,695,200,40);
		this.NUT_CHINH_SUA.setFont(new Font("Cambria", Font.BOLD, 30));
		this.NUT_CHINH_SUA.setFocusable(false);
		this.NUT_CHINH_SUA.addActionListener(this);
		
		this.Ban_chinhsua = new JLabel();
		this.Ban_chinhsua.setLayout(null);
		this.Ban_chinhsua.setBackground(new Color(100, 149, 237));
		this.Ban_chinhsua.setOpaque(true);
		this.Ban_chinhsua.setVisible(true);
		this.Ban_chinhsua.add(this.CHINHSUADV);
		this.Ban_chinhsua.add(this.MA_DV_CHINHSUA);
		this.Ban_chinhsua.add(this.MA_DV_CHINHSUA_TF);
		this.Ban_chinhsua.add(this.MADV_TD);
		this.Ban_chinhsua.add(this.MADV_TD_TF);
		this.Ban_chinhsua.add(this.Ten_DV_CHINHSUA);
		this.Ban_chinhsua.add(this.TEN_DV_CHINHSUA_TF);
		this.Ban_chinhsua.add(this.TENDV_TD);
		this.Ban_chinhsua.add(this.TENDV_TD_TF);
		this.Ban_chinhsua.add(this.Ngay_CHINHSUA);
		this.Ban_chinhsua.add(this.Ngay_CHINHSUA_TF);
		this.Ban_chinhsua.add(this.NGAY_TD);
		this.Ban_chinhsua.add(this.NGAY_TF);
		this.Ban_chinhsua.add(this.Thang_CHINHSUA);
		this.Ban_chinhsua.add(this.Thang_CHINHSUA_TF);
		this.Ban_chinhsua.add(this.THANG_TD);
		this.Ban_chinhsua.add(this.THANG_TF);
		this.Ban_chinhsua.add(this.Nam_CHINHSUA);
		this.Ban_chinhsua.add(this.Nam_CHINHSUA_TF);
		this.Ban_chinhsua.add(this.NAM_TD);
		this.Ban_chinhsua.add(this.NAM_TF);
		this.Ban_chinhsua.add(this.HUONG_DAN);
		this.Ban_chinhsua.add(this.NUT_XOA);
		this.Ban_chinhsua.add(this.NUT_CHINH_SUA);
		
		this.chinh_sua = new JTable();
		this.chinh_sua_Scr = new JScrollPane(this.chinh_sua);
		this.chinh_sua_Scr.setBorder(BorderFactory.createLineBorder(new Color(100, 149, 237)));
		this.chinh_sua.getTableHeader().setBackground(new Color(100, 149, 237));
		this.chinh_sua.getTableHeader().setForeground(Color.WHITE);
		this.chinh_sua.setForeground(Color.BLACK);
		this.chinh_sua.setFont(new Font("Cambria", Font.BOLD, 16));
		this.chinh_sua.setShowHorizontalLines(true);
		this.chinh_sua.setGridColor(new Color(100, 149, 237));
		this.chinh_sua.setFocusable(false);
		this.chinh_sua.setDefaultEditor(Object.class, null);
		this.Chinhsua_DFT = (DefaultTableModel) this.chinh_sua.getModel();
		
		this.Ban_chinhsua_Table = new JLabel();
		this.Ban_chinhsua_Table.setLayout( new BorderLayout());
		this.Ban_chinhsua_Table.setBackground(Color.WHITE);
		this.Ban_chinhsua_Table.setOpaque(true);
		this.Ban_chinhsua_Table.setVisible(true);
		this.Ban_chinhsua_Table.add(this.chinh_sua_Scr, BorderLayout.CENTER);
		
		this.Phong_Chinhsua = new JPanel();
		this.Phong_Chinhsua.setLayout(new GridLayout());
		this.Phong_Chinhsua.setBackground(Color.WHITE);
		this.Phong_Chinhsua.add(this.Ban_chinhsua);
		this.Phong_Chinhsua.add(this.Ban_chinhsua_Table);
		this.Phong_Chinhsua.setVisible(false);
		
		this.dangxuat = new JButton ("ĐĂNG XUẤT");
		this.dangxuat.setVisible(true);
		this.dangxuat.setFocusable(false);
		this.dangxuat.setBorder(BorderFactory.createLineBorder(Color.black,3));
		this.dangxuat.setFont(new Font("Cambria", Font.BOLD, 40));
		this.dangxuat.setBackground(new Color(100, 149, 237));
		this.dangxuat.addActionListener(this);
		
		this.anh1 = new JLabel();
		this.anh1.setVisible(true);
		this.anh1.setBounds(550, 15, 380, 380);
		this.anh1.setOpaque(true);
		this.anh1.setIcon(anhd1);
		
		this.menu_group = new JLabel();
		this.menu_group.setLayout(new GridLayout());
		this.menu_group.setPreferredSize(new Dimension(1920,80));
		this.menu_group.add(this.ketnapdv);
		this.menu_group.add(this.chinhsua);
		this.menu_group.add(this.dangxuat);
		
		this.welcome_label= new JLabel();
		this.welcome_label.setLayout(null);
		this.welcome_label.setBackground(Color.white);
		this.welcome_label.setOpaque(true);
		this.welcome_label.add(this.doanthanhnien);
		this.welcome_label.add(this.ChiDoan);
		this.welcome_label.add(this.qldoanvien);
		this.welcome_label.add(this.anh1);
		this.welcome_label.setVisible(true);
		
		this.phong_chinh = new JPanel();
		this.phong_chinh.setLayout(new BorderLayout());
		this.phong_chinh.add(this.menu_group,BorderLayout.SOUTH);
		this.phong_chinh.add(this.welcome_label,BorderLayout.CENTER);
		
		this.giao_dien_chinh = new JFrame("QUẢN LÝ ĐOÀN VIÊN");
		this.giao_dien_chinh.setVisible(true);
		this.giao_dien_chinh.setSize(700,500);
		this.giao_dien_chinh.setLocationRelativeTo(null);
		this.giao_dien_chinh.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.giao_dien_chinh.setIconImage(icon.getImage());
		this.giao_dien_chinh.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.giao_dien_chinh.getContentPane().setBackground(new Color(255, 255, 255));
		this.giao_dien_chinh.setContentPane(this.phong_chinh);
		
		try {
            Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("Select MA_CD FROM QLDV.chi_doan where Ten_CD = '"+this.chidoan+"'");
            while(rs.next()) {
            	Ma_Chi_Doan = rs.getString(1);
            }
		} catch (Exception ex) {
            ex.printStackTrace();
        }

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== this.dangxuat) {
			String choose[] = {"Ok", "Cancel"};
			int get =  JOptionPane.showOptionDialog(null, "Bạn muốn đăng xuất?", "", 0, 0, alert, choose, e);
			if (get == 0) {
                this.giao_dien_chinh.dispose();
                new Cuasodangnhap();
            }
		}
		
		if(e.getSource() == this.ketnapdv) {
			this.MA_DV_CHINHSUA_TF.setText(null);
            this.TEN_DV_CHINHSUA_TF.setText(null);
            this.Ngay_CHINHSUA_TF.setText(null);
            this.Thang_CHINHSUA_TF.setText(null);
            this.Nam_CHINHSUA_TF.setText(null);
            this.MADV_TD_TF.setText(null);
            this.TENDV_TD_TF.setText(null);
            this.NGAY_TF.setText(null);
            this.THANG_TF.setText(null);
            this.NAM_TF.setText(null);
			
			this.welcome_label.setVisible(false);
			this.phong_chinh.remove(this.welcome_label);
			
			this.Phong_Chinhsua.setVisible(false);
			this.phong_chinh.remove(this.Phong_Chinhsua);
			
			this.phong_chinh.add(this.phong_them, BorderLayout.CENTER);
			this.phong_them.setVisible(true);
			
			this.ketnapdv.setBackground(new Color(117,112,112));
			this.chinhsua.setBackground(new Color(100, 149, 237));
			
			try {
                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
                Statement stmt = connection.createStatement();
                ResultSet rs1 = stmt.executeQuery("Select MA_DV , TEN_DV, Ngay_KETNAP from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
                ResultSetMetaData rsmd = rs1.getMetaData();
                this.Them_DFT.getDataVector().removeAllElements();
                int cols = rsmd.getColumnCount();
                String[] colName = new String[cols];
                for (int i = 0; i < cols; i++)
                    colName[i] = rsmd.getColumnName(i + 1);
                this.Them_DFT.setColumnIdentifiers(colName);
                String MA_DV, TEN_DV, Ngay_KN;
                while (rs1.next()) {
                	MA_DV = rs1.getString(1);
                	TEN_DV = rs1.getString(2);
                	Ngay_KN = rs1.getString(3);
                    String[] row = { MA_DV, TEN_DV, Ngay_KN };
                    this.Them_DFT.addRow(row);
                }
                stmt.close();
                connection.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
		}
		
		if(e.getSource() == this.NUT_THEM) {
			if(this.Ma_DV_TF.getText().length() != 0) {
				if(this.Ten_DV_TF.getText().length() != 0) {
					if(this.Ngay_KN_TF.getText().length() != 0) {
						if(this.Thang_KN_TF.getText().length()!=0) {
							if(this.Nam_KN_TF.getText().length() != 0) {
								if(Integer.parseInt(this.Nam_KN_TF.getText()) < this.year) {
									try {
						                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
						                Statement stmt = connection.createStatement();
						                ResultSet rs = stmt.executeQuery("Select MA_CD FROM QLDV.chi_doan where Ten_CD = '"+this.chidoan+"'");
						                while(rs.next()) {
						                	Ma_Chi_Doan = rs.getString(1);
						                }
						                ArrayList<String> MADV = new ArrayList<String>();
						                ResultSet rs0 = stmt.executeQuery("Select MA_DV FROM QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"'");
						                while(rs0.next()) {
						                	MADV.add(rs0.getString(1));
						                }
						                if(MADV.contains(this.Ma_DV_TF.getText()) != true){
						                stmt.executeUpdate("Insert into QLDV.doan_vien values("+this.Ma_Chi_Doan+",'"+this.Ma_DV_TF.getText()+"', '"+this.Ten_DV_TF.getText()+"','"+this.Nam_KN_TF.getText()+"-"+this.Thang_KN_TF.getText()+"-"+this.Ngay_KN_TF.getText()+"')");
						                ResultSet rs1 = stmt.executeQuery("Select MA_DV , TEN_DV, Ngay_KETNAP from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
						                ResultSetMetaData rsmd = rs1.getMetaData();
						                this.Them_DFT.getDataVector().removeAllElements();
						                int cols = rsmd.getColumnCount();
						                String[] colName = new String[cols];
						                for (int i = 0; i < cols; i++)
						                    colName[i] = rsmd.getColumnName(i + 1);
						                this.Them_DFT.setColumnIdentifiers(colName);
						                String MA_DV, TEN_DV, Ngay_KN;
						                while (rs1.next()) {
						                	MA_DV = rs1.getString(1);
						                	TEN_DV = rs1.getString(2);
						                	Ngay_KN = rs1.getString(3);
						                    String[] row = { MA_DV, TEN_DV, Ngay_KN };
						                    this.Them_DFT.addRow(row);
						                }
						                JOptionPane.showMessageDialog(null, "Thêm đoàn viên thành công!",
						                        "Thông báo", JOptionPane.INFORMATION_MESSAGE);
						                this.Ten_DV_TF.setText(null);
						    			this.Ma_DV_TF.setText(null);
						    			this.Ngay_KN_TF.setText(null);
						    			this.Thang_KN_TF.setText(null);
						    			this.Nam_KN_TF.setText(null);
									}else {
										JOptionPane.showMessageDialog(null, "Mã đoàn viên đã tồn tại!",
						                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
									}
						                stmt.close();
						                connection.close();
						            } catch (Exception ex) {
						            	JOptionPane.showMessageDialog(null, "Thêm đoàn viên không thành công!",
						                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
						            }
								}else if(Integer.parseInt(this.Nam_KN_TF.getText()) > this.year){
									JOptionPane.showMessageDialog(null, "Sai năm!",
					                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
								}else if(Integer.parseInt(this.Nam_KN_TF.getText()) == this.year) {
									if(Integer.parseInt(this.Thang_KN_TF.getText()) <= this.month) {
										if(Integer.parseInt(this.Ngay_KN_TF.getText()) <= this.day){										
											try {
								                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
								                Statement stmt = connection.createStatement();
								                ResultSet rs = stmt.executeQuery("Select MA_CD FROM QLDV.chi_doan where Ten_CD = '"+this.chidoan+"'");
								                while(rs.next()) {
								                	Ma_Chi_Doan = rs.getString(1);
								                }
								                ArrayList<String> MADV = new ArrayList<String>();
								                ResultSet rs0 = stmt.executeQuery("Select MA_DV FROM QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"'");
								                while(rs0.next()) {
								                	MADV.add(rs0.getString(1));
								                }
								                if(MADV.contains(this.Ma_DV_TF.getText()) != true){
								                stmt.executeUpdate("Insert into QLDV.doan_vien values("+this.Ma_Chi_Doan+",'"+this.Ma_DV_TF.getText()+"', '"+this.Ten_DV_TF.getText()+"','"+this.Nam_KN_TF.getText()+"-"+this.Thang_KN_TF.getText()+"-"+this.Ngay_KN_TF.getText()+"')");
								                ResultSet rs1 = stmt.executeQuery("Select MA_DV , TEN_DV, Ngay_KETNAP from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
								                ResultSetMetaData rsmd = rs1.getMetaData();
								                this.Them_DFT.getDataVector().removeAllElements();
								                int cols = rsmd.getColumnCount();
								                String[] colName = new String[cols];
								                for (int i = 0; i < cols; i++)
								                    colName[i] = rsmd.getColumnName(i + 1);
								                this.Them_DFT.setColumnIdentifiers(colName);
								                String MA_DV, TEN_DV, Ngay_KN;
								                while (rs1.next()) {
								                	MA_DV = rs1.getString(1);
								                	TEN_DV = rs1.getString(2);
								                	Ngay_KN = rs1.getString(3);
								                    String[] row = { MA_DV, TEN_DV, Ngay_KN };
								                    this.Them_DFT.addRow(row);
								                }
								                JOptionPane.showMessageDialog(null, "Thêm đoàn viên thành công!",
								                        "Lưu ý!!!", JOptionPane.INFORMATION_MESSAGE);
								                this.Ten_DV_TF.setText(null);
								    			this.Ma_DV_TF.setText(null);
								    			this.Ngay_KN_TF.setText(null);
								    			this.Thang_KN_TF.setText(null);
								    			this.Nam_KN_TF.setText(null);
											}else {
												JOptionPane.showMessageDialog(null, "Mã đoàn viên đã tồn tại!",
								                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
											}
								                stmt.close();
								                connection.close();
								            } catch (Exception ex) {
								            	JOptionPane.showMessageDialog(null, "Thêm đoàn viên không thành công!",
								                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
								            }
											
										}else {
											JOptionPane.showMessageDialog(null, "Sai ngày!",
							                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
										}
									}else {
										JOptionPane.showMessageDialog(null, "Sai tháng!",
						                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
									}
								}
							}else {
								JOptionPane.showMessageDialog(null, "Nhập năm kết nạp đoàn viên!",
				                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
							}
						}else {
							JOptionPane.showMessageDialog(null, "Nhập tháng kết nạp đoàn viên!",
			                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
						}
					}else {
						JOptionPane.showMessageDialog(null, "Nhập ngày kết nạp đoàn viên!",
		                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(null, "Nhập tên đoàn viên!",
	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(null, "Nhập mã đoàn viên!",
                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
			}
		}
		
		if(e.getSource()== this.chinhsua) {
			this.Ten_DV_TF.setText(null);
			this.Ma_DV_TF.setText(null);
			this.Ngay_KN_TF.setText(null);
			this.Thang_KN_TF.setText(null);
			this.Nam_KN_TF.setText(null);
			
			this.ketnapdv.setBackground(new Color(100, 149, 237));
			this.chinhsua.setBackground(new Color(117,112,112));
			this.welcome_label.setVisible(false);
			this.phong_chinh.remove(welcome_label);
			
			this.phong_them.setVisible(false);
			this.phong_chinh.remove(this.phong_them);
			
			this.phong_chinh.add(this.Phong_Chinhsua);
			this.Phong_Chinhsua.setVisible(true);
			
			try {
                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
                Statement stmt = connection.createStatement();
                ResultSet rs1 = stmt.executeQuery("Select MA_DV  , TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
                ResultSetMetaData rsmd = rs1.getMetaData();
                this.Chinhsua_DFT.getDataVector().removeAllElements();
                int cols = rsmd.getColumnCount();
                String[] colName = new String[cols];
                for (int i = 0; i < cols; i++)
                    colName[i] = rsmd.getColumnName(i + 1);
                this.Chinhsua_DFT.setColumnIdentifiers(colName);
                String MA_DV, TEN_DV, Ngay_KN, Thang_KN, Nam_KN;
                while (rs1.next()) {
                	MA_DV = rs1.getString(1);
                	TEN_DV = rs1.getString(2);
                	Ngay_KN = rs1.getString(3);
                	Thang_KN = rs1.getString(4);
                	Nam_KN = rs1.getString(5);
                    String[] row = { MA_DV, TEN_DV, Ngay_KN ,Thang_KN,Nam_KN};
                    this.Chinhsua_DFT.addRow(row);
                }
                stmt.close();
                connection.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
			this.chinh_sua.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {
	            int i = Giaodienchinh.this.chinh_sua.getSelectedRow();
	            Giaodienchinh.this.MA_DV_CHINHSUA_TF.setText(Giaodienchinh.this.chinh_sua.getValueAt(i, 0).toString());
	            Giaodienchinh.this.TEN_DV_CHINHSUA_TF.setText(Giaodienchinh.this.chinh_sua.getValueAt(i, 1).toString());
	            Giaodienchinh.this.Ngay_CHINHSUA_TF.setText(Giaodienchinh.this.chinh_sua.getValueAt(i, 2).toString());
	            Giaodienchinh.this.Thang_CHINHSUA_TF.setText(Giaodienchinh.this.chinh_sua.getValueAt(i, 3).toString());
	            Giaodienchinh.this.Nam_CHINHSUA_TF.setText(Giaodienchinh.this.chinh_sua.getValueAt(i, 4).toString());
	            }
			});
		}
		
		if(e.getSource() == this.NUT_XOA) {
			if(this.MA_DV_CHINHSUA_TF.getText().length() != 0) {
				if(this.TEN_DV_CHINHSUA_TF.getText().length() != 0) {
					if(this.Ngay_CHINHSUA_TF.getText().length() != 0) {
						if(this.Thang_CHINHSUA_TF.getText().length() !=0) {
							if(this.Nam_CHINHSUA_TF.getText().length() != 0) {
								try {
					                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
					                Statement stmt = connection.createStatement();
					                ResultSet rs1 = stmt.executeQuery("Select MA_DV  , TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' and MA_DV = '"+this.MA_DV_CHINHSUA_TF.getText()+"' ");
					                while(rs1.next()) {
					                	this.MADV = rs1.getString(1);
					                	this.TENDV = rs1.getString(2);
					                	this.NGAY = rs1.getString(3);
					                	this.THANG = rs1.getString(4);
					                	this.NAM = rs1.getString(5);
					                }
					                if(this.MADV.equals(this.MA_DV_CHINHSUA_TF.getText())) {
					                	if(this.TENDV.equals(this.TEN_DV_CHINHSUA_TF.getText())) {
					                		if(this.NGAY.equals(this.Ngay_CHINHSUA_TF.getText())) {
					                			if(this.THANG.equals(this.Thang_CHINHSUA_TF.getText())) {
					                				if(this.NAM.equals(this.Nam_CHINHSUA_TF.getText())) {
					                					stmt.executeUpdate("DELETE FROM QLDV.doan_vien where MA_DV = '"+this.MA_DV_CHINHSUA_TF.getText()+"' and Ten_DV = '"+this.TEN_DV_CHINHSUA_TF.getText()+"'");
					                					JOptionPane.showMessageDialog(null, "Thông tin đã được xóa!",
					                	                        "Thông báo", JOptionPane.INFORMATION_MESSAGE);
					                					ResultSet rs2 = stmt.executeQuery("Select MA_DV  , TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
					                	                ResultSetMetaData rsmd = rs2.getMetaData();
					                	                this.Chinhsua_DFT.getDataVector().removeAllElements();
					                	                int cols = rsmd.getColumnCount();
					                	                String[] colName = new String[cols];
					                	                for (int i = 0; i < cols; i++)
					                	                    colName[i] = rsmd.getColumnName(i + 1);
					                	                this.Chinhsua_DFT.setColumnIdentifiers(colName);
					                	                String MA_DV, TEN_DV, Ngay_KN, Thang_KN, Nam_KN;
					                	                while (rs2.next()) {
					                	                	MA_DV = rs2.getString(1);
					                	                	TEN_DV = rs2.getString(2);
					                	                	Ngay_KN = rs2.getString(3);
					                	                	Thang_KN = rs2.getString(4);
					                	                	Nam_KN = rs2.getString(5);
					                	                    String[] row = { MA_DV, TEN_DV, Ngay_KN ,Thang_KN,Nam_KN};
					                	                    this.Chinhsua_DFT.addRow(row);
					                	                }
					                				}else {
					                					JOptionPane.showMessageDialog(null, "Thông tin không tồn tại!",
					                	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					                				}
					                			}else {
					                				JOptionPane.showMessageDialog(null, "Thông tin không tồn tại!",
				                	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					                			}
					                		}else {
					                			JOptionPane.showMessageDialog(null, "Thông tin không tồn tại!",
			                	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					                		}
					                	}else {
					                		JOptionPane.showMessageDialog(null, "Thông tin không tồn tại!",
		                	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					                	}
					                }else {
					                	JOptionPane.showMessageDialog(null, "Thông tin không tồn tại!",
	                	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					                }
					                connection.close();
					            } catch (Exception ex) {
					                ex.printStackTrace();
					            }
							}
						}else {
							JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
			                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
						}
					}else {
						JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
		                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
			}
		}
		
		if(e.getSource() == this.NUT_CHINH_SUA) {
			if(this.MA_DV_CHINHSUA_TF.getText().length() != 0) {
				if(this.TEN_DV_CHINHSUA_TF.getText().length() != 0) {
					if(this.Ngay_CHINHSUA_TF.getText().length() != 0) {
						if(this.Thang_CHINHSUA_TF.getText().length() !=0) {
							if(this.Nam_CHINHSUA_TF.getText().length() != 0) {
								if(this.MADV_TD_TF.getText().length() != 0) {
									if(this.TENDV_TD_TF.getText().length() != 0) {
										if(this.NGAY_TF.getText().length() != 0) {
											if(this.THANG_TF.getText().length() != 0) {
												if(this.NAM_TF.getText().length() != 0) {
													if(Integer.parseInt(this.NAM_TF.getText()) < this.year) {
														try {
															ArrayList<String> madv = new ArrayList<String>();
											                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
											                Statement stmt = connection.createStatement();
											                ResultSet rs1 = stmt.executeQuery("Select MA_DV from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' ");
											                while(rs1.next()) {
											                	madv.add(rs1.getString(1));
											                }
											                if(madv.contains(this.MA_DV_CHINHSUA_TF.getText())) {
											                	
													                ResultSet rs2 = stmt.executeQuery("Select TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' and MA_DV = '"+this.MA_DV_CHINHSUA_TF.getText()+"' ");
													                while(rs2.next()) {
													                	this.tendv = rs2.getString(1);
													                	this.ngay = rs2.getString(2);
													                	this.thang = rs2.getString(3);
													                	this.nam = rs2.getString(4);
													                }
													                	if(this.tendv.equals(this.TEN_DV_CHINHSUA_TF.getText()) ) {
													                		if(this.ngay.equals(this.Ngay_CHINHSUA_TF.getText()) ) {
															                	if(this.thang.equals(this.Thang_CHINHSUA_TF.getText())) {
															                		if(this.nam.equals(this.Nam_CHINHSUA_TF.getText())) {
															                			stmt.executeUpdate("UPDATE QLDV.doan_vien set MA_DV = '"+this.MADV_TD_TF.getText()+"', TEN_DV = '"+this.TENDV_TD_TF.getText()+"' , Ngay_KETNAP = '"+this.NAM_TF.getText()+"-"+this.THANG_TF.getText()+"-"+this.NGAY_TF.getText()+"' where MA_CD = '"+this.Ma_Chi_Doan+"' and MA_DV = '"+this.MA_DV_CHINHSUA_TF.getText()+"' ");
															                			JOptionPane.showMessageDialog(null, "Chỉnh sửa thành công!",
																		                        "Thông báo!!!", JOptionPane.INFORMATION_MESSAGE);
													                					ResultSet rs3 = stmt.executeQuery("Select MA_DV  , TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
													                	                ResultSetMetaData rsmd = rs3.getMetaData();
													                	                this.Chinhsua_DFT.getDataVector().removeAllElements();
													                	                int cols = rsmd.getColumnCount();
													                	                String[] colName = new String[cols];
													                	                for (int i = 0; i < cols; i++)
													                	                    colName[i] = rsmd.getColumnName(i + 1);
													                	                this.Chinhsua_DFT.setColumnIdentifiers(colName);
													                	                String MA_DV, TEN_DV, Ngay_KN, Thang_KN, Nam_KN;
													                	                while (rs3.next()) {
													                	                	MA_DV = rs3.getString(1);
													                	                	TEN_DV = rs3.getString(2);
													                	                	Ngay_KN = rs3.getString(3);
													                	                	Thang_KN = rs3.getString(4);
													                	                	Nam_KN = rs3.getString(5);
													                	                    String[] row = { MA_DV, TEN_DV, Ngay_KN ,Thang_KN,Nam_KN};
													                	                    this.Chinhsua_DFT.addRow(row);
													                	                }
													                	                this.MA_DV_CHINHSUA_TF.setText(null);
													                	                this.TEN_DV_CHINHSUA_TF.setText(null);
													                	                this.Ngay_CHINHSUA_TF.setText(null);
													                	                this.Thang_CHINHSUA_TF.setText(null);
													                	                this.Nam_CHINHSUA_TF.setText(null);
													                	                this.MADV_TD_TF.setText(null);
													                	                this.TENDV_TD_TF.setText(null);
													                	                this.NGAY_TF.setText(null);
													                	                this.THANG_TF.setText(null);
													                	                this.NAM_TF.setText(null);
															                		}else {
															                			JOptionPane.showMessageDialog(null, "Sai thông tin năm!",
																		                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);	
															                		}
															                	}else {
															                		JOptionPane.showMessageDialog(null, "Sai thông tin tháng!",
																	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
															                	}
															                }else {
															                	JOptionPane.showMessageDialog(null, "Sai thông tin ngày!",
																                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
															                }
														                }else {
														                	JOptionPane.showMessageDialog(null, "Sai tên đoàn viên!",
															                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
														                }
													                }else {
													                	JOptionPane.showMessageDialog(null, "Sai mã đoàn viên!",
														                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
													                }
											                
											                connection.close();
														}catch (Exception ex) {
											                JOptionPane.showMessageDialog(null, "Không thể chỉnh sửa thông tin!",
															                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
														}
											}else if(Integer.parseInt(this.NAM_TF.getText()) > this.year){
												JOptionPane.showMessageDialog(null, "Sai năm!",
								                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
											}else if(Integer.parseInt(this.NAM_TF.getText()) == this.year) {
												if(Integer.parseInt(this.THANG_TF.getText()) <= this.month) {
													if(Integer.parseInt(this.NGAY_TF.getText()) <= this.day){	
														try {
														ArrayList<String> madv = new ArrayList<String>();
											                Connection connection = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
											                Statement stmt = connection.createStatement();
											                ResultSet rs1 = stmt.executeQuery("Select MA_DV from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' ");
											                while(rs1.next()) {
											                	madv.add(rs1.getString(1));
											                }
											                if(madv.contains(this.MA_DV_CHINHSUA_TF.getText())) {
											                	
													                ResultSet rs2 = stmt.executeQuery("Select TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' and MA_DV = '"+this.MA_DV_CHINHSUA_TF.getText()+"' ");
													                while(rs2.next()) {
													                	this.tendv = rs2.getString(1);
													                	this.ngay = rs2.getString(2);
													                	this.thang = rs2.getString(3);
													                	this.nam = rs2.getString(4);
													                }
													                	if(this.tendv.equals(this.TEN_DV_CHINHSUA_TF.getText()) ) {
													                		if(this.ngay.equals(this.Ngay_CHINHSUA_TF.getText()) ) {
															                	if(this.thang.equals(this.Thang_CHINHSUA_TF.getText())) {
															                		if(this.nam.equals(this.Nam_CHINHSUA_TF.getText())) {
															                			stmt.executeUpdate("UPDATE QLDV.doan_vien set MA_DV = '"+this.MADV_TD_TF.getText()+"', TEN_DV = '"+this.TENDV_TD_TF.getText()+"' , Ngay_KETNAP = '"+this.NAM_TF.getText()+"-"+this.THANG_TF.getText()+"-"+this.NGAY_TF.getText()+"' where MA_CD = '"+this.Ma_Chi_Doan+"' and MA_DV = '"+this.MA_DV_CHINHSUA_TF.getText()+"' ");
															                			JOptionPane.showMessageDialog(null, "Chỉnh sửa thành công!",
																		                        "Thông báo!!!", JOptionPane.INFORMATION_MESSAGE);
													                					ResultSet rs3 = stmt.executeQuery("Select MA_DV  , TEN_DV , day(Ngay_KETNAP) as Ngày, month(Ngay_KETNAP)as Tháng, year(Ngay_KETNAP) as Năm from QLDV.doan_vien where MA_CD = '"+this.Ma_Chi_Doan+"' order by MA_DV");
													                	                ResultSetMetaData rsmd = rs3.getMetaData();
													                	                this.Chinhsua_DFT.getDataVector().removeAllElements();
													                	                int cols = rsmd.getColumnCount();
													                	                String[] colName = new String[cols];
													                	                for (int i = 0; i < cols; i++)
													                	                    colName[i] = rsmd.getColumnName(i + 1);
													                	                this.Chinhsua_DFT.setColumnIdentifiers(colName);
													                	                String MA_DV, TEN_DV, Ngay_KN, Thang_KN, Nam_KN;
													                	                while (rs3.next()) {
													                	                	MA_DV = rs3.getString(1);
													                	                	TEN_DV = rs3.getString(2);
													                	                	Ngay_KN = rs3.getString(3);
													                	                	Thang_KN = rs3.getString(4);
													                	                	Nam_KN = rs3.getString(5);
													                	                    String[] row = { MA_DV, TEN_DV, Ngay_KN ,Thang_KN,Nam_KN};
													                	                    this.Chinhsua_DFT.addRow(row);
													                	                }
													                	                this.MA_DV_CHINHSUA_TF.setText(null);
													                	                this.TEN_DV_CHINHSUA_TF.setText(null);
													                	                this.Ngay_CHINHSUA_TF.setText(null);
													                	                this.Thang_CHINHSUA_TF.setText(null);
													                	                this.Nam_CHINHSUA_TF.setText(null);
													                	                this.MADV_TD_TF.setText(null);
													                	                this.TENDV_TD_TF.setText(null);
													                	                this.NGAY_TF.setText(null);
													                	                this.THANG_TF.setText(null);
													                	                this.NAM_TF.setText(null);
															                		}else {
															                			JOptionPane.showMessageDialog(null, "Sai thông tin năm!",
																		                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);	
															                		}
															                	}else {
															                		JOptionPane.showMessageDialog(null, "Sai thông tin tháng!",
																	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
															                	}
															                }else {
															                	JOptionPane.showMessageDialog(null, "Sai thông tin ngày!",
																                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
															                }
														                }else {
														                	JOptionPane.showMessageDialog(null, "Sai tên đoàn viên!",
															                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
														                }
													                }else {
													                	JOptionPane.showMessageDialog(null, "Sai mã đoàn viên!",
														                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
													                }
											                
											                connection.close();
														}catch (Exception ex) {
											                JOptionPane.showMessageDialog(null, "Không thể chỉnh sửa thông tin!",
															                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
														}
														
													}else {
														JOptionPane.showMessageDialog(null, "Sai ngày!",
										                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
													}
												}else {
													JOptionPane.showMessageDialog(null, "Sai tháng!",
									                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
												}
											}
														
												
											}else {
												JOptionPane.showMessageDialog(null, "Hãy điền đầy đủ thông tin cần thay đổi!",
								                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
											}
										}else {
											JOptionPane.showMessageDialog(null, "Hãy điền đầy đủ thông tin cần thay đổi!",
							                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
										}
									}else {
										JOptionPane.showMessageDialog(null, "Hãy điền đầy đủ thông tin cần thay đổi!",
						                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
									}
								}else {
									JOptionPane.showMessageDialog(null, "Hãy điền đầy đủ thông tin cần thay đổi!",
					                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
								}
							}else {
								JOptionPane.showMessageDialog(null, "Hãy điền đầy đủ thông tin cần thay đổi!",
				                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
							}
						}else {
							JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
			                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
						}
					}else {
						JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
		                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
	                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
                        "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
			}
		}else {
			JOptionPane.showMessageDialog(null, "Chọn trên bảng HOẶC điền đầy đủ thông tin!",
                    "Lưu ý!!!", JOptionPane.WARNING_MESSAGE);
		}
		
	}
	}
}
